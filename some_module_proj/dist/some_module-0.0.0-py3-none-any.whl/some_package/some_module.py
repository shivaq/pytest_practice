def some_func():
    return 2020